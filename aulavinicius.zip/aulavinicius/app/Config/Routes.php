<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'Home::index');

$routes->get('/login', 'AuthController::login');

$routes->post('/autenticar', 'AuthController::autenticar');

$routes->get('/register', 'AuthController::register');

$routes->post('/salvar', 'AuthController::salvar');

$routes->get('/logout', 'AuthController::logout');


// FEED REAL (protegido)
$routes->group('', ['filter' => 'auth'], function($routes) {

    $routes->get('/feed', 'FeedController::index');

    $routes->get('/dashboard', 'FeedController::index');

    $routes->get('/perfil', 'FeedController::index');

    $routes->get('/post/create', 'FeedController::index');

    $routes->get('/post/edit', 'FeedController::index');
});