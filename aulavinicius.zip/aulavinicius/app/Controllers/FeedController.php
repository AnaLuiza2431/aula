<?php

namespace App\Controllers;

class FeedController extends BaseController
{
    public function index()
    {
        return view('feed');
    }
}