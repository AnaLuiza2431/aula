<?php

namespace App\Controllers;

use App\Models\UsuarioModel;

class AuthController extends BaseController
{
    public function login()
    {
        return view('auth/login');
    }

    public function autenticar()
    {
        $session = session();
        $model = new UsuarioModel();

        $email = $this->request->getPost('email');
        $senha = $this->request->getPost('senha');

        $usuario = $model->where('email', $email)->first();

        if ($usuario && password_verify($senha, $usuario['senha'])) {

            session()->regenerate();

            $session->set([
                'id' => $usuario['id'],
                'nome' => $usuario['nome'],
                'isLoggedIn' => true
            ]);

            return redirect()->to('/feed')
                ->with('success', 'Bem-vindo, ' . $usuario['nome']);
        }

        return redirect()->back()
            ->with('error', 'E-mail ou senha inválidos');
    }

    public function register()
    {
        return view('auth/register');
    }

    public function salvar()
    {
        $model = new UsuarioModel();

        $senha = $this->request->getPost('senha');
        $confirmar = $this->request->getPost('confirmar_senha');

        if ($senha != $confirmar) {
            return redirect()->back()
                ->with('error', 'As senhas não coincidem');
        }

        if (strlen($senha) < 6) {
            return redirect()->back()
                ->with('error', 'A senha deve ter no mínimo 6 caracteres');
        }

        $model->save([
            'nome' => $this->request->getPost('nome'),
            'email' => $this->request->getPost('email'),
            'senha' => password_hash($senha, PASSWORD_DEFAULT)
        ]);

        return redirect()->to('/login')
            ->with('success', 'Cadastro realizado com sucesso');
    }

    public function logout()
    {
        session()->destroy();

        return redirect()->to('/login')
            ->with('success', 'Você saiu da sua conta');
    }
}