<?php

namespace App\Models;

use CodeIgniter\Model;

class PostModel extends Model
{
    protected $table = 'postagens';
    protected $primaryKey = 'id';
    protected $allowedFields = ['usuario_id', 'texto'];
    protected $useTimestamps = true;
}