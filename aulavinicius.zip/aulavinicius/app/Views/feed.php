<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Feed</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, Helvetica, sans-serif;
        }

        body{
            background:#f0f2f5;
        }

        /* NAVBAR */
        .navbar{
            background:#4f46e5;
            color:white;
            padding:15px 30px;
            display:flex;
            justify-content:space-between;
            align-items:center;
        }

        .navbar h2{
            font-size:18px;
        }

        .navbar a{
            color:white;
            text-decoration:none;
            font-weight:bold;
        }

        /* CONTAINER */
        .container{
            max-width:600px;
            margin:30px auto;
        }

        /* CARD POST */
        .post{
            background:white;
            padding:20px;
            border-radius:10px;
            margin-bottom:15px;
            box-shadow:0 2px 8px rgba(0,0,0,0.1);
        }

        .post h3{
            margin-bottom:10px;
            color:#333;
        }

        .post p{
            color:#555;
            line-height:1.4;
        }

        /* WELCOME */
        .welcome{
            margin-bottom:20px;
            font-size:18px;
            color:#333;
        }

        .btn{
            display:inline-block;
            margin-top:10px;
            padding:8px 12px;
            background:#4f46e5;
            color:white;
            border-radius:6px;
            text-decoration:none;
            font-size:14px;
        }

    </style>

</head>
<body>

<!-- NAVBAR -->
<div class="navbar">

    <h2>Mini Rede Social</h2>

    <a href="/logout">Sair</a>

</div>

<!-- CONTAINER -->
<div class="container">

    <div class="welcome">
        Bem-vindo, <b><?= session()->get('nome') ?></b> 👋
    </div>

    <!-- POST FAKE 1 -->
    <div class="post">
        <h3>Postagem 1</h3>
        <p>Hoje estou aprendendo CodeIgniter 4 e entendendo sessions e filters!</p>
        <a class="btn" href="#">Curtir</a>
    </div>

    <!-- POST FAKE 2 -->
    <div class="post">
        <h3>Postagem 2</h3>
        <p>Esse feed é um protótipo de rede social feito em PHP com CI4.</p>
        <a class="btn" href="#">Curtir</a>
    </div>

    <!-- POST FAKE 3 -->
    <div class="post">
        <h3>Postagem 3</h3>
        <p>Sistema de login funcionando com autenticação e proteção de rotas!</p>
        <a class="btn" href="#">Curtir</a>
    </div>

</div>

</body>
</html>