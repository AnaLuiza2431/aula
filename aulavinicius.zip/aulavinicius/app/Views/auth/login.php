<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, Helvetica, sans-serif;
        }

        body{
            background:linear-gradient(135deg, #4f46e5, #7c3aed);
            height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
        }

        .login-box{
            background:white;
            width:350px;
            padding:40px;
            border-radius:15px;
            box-shadow:0 10px 25px rgba(0,0,0,0.2);
        }

        h1{
            text-align:center;
            margin-bottom:30px;
            color:#333;
        }

        input{
            width:100%;
            padding:12px;
            margin-bottom:15px;
            border:1px solid #ccc;
            border-radius:8px;
            outline:none;
            transition:0.3s;
        }

        input:focus{
            border-color:#7c3aed;
        }

        button{
            width:100%;
            padding:12px;
            border:none;
            border-radius:8px;
            background:#4f46e5;
            color:white;
            font-size:16px;
            cursor:pointer;
            transition:0.3s;
        }

        button:hover{
            background:#4338ca;
        }

        .register{
            display:block;
            text-align:center;
            margin-top:20px;
            text-decoration:none;
            color:#4f46e5;
            font-weight:bold;
        }

        .forgot{
            display:block;
            text-align:right;
            margin-top:-5px;
            margin-bottom:20px;
            font-size:14px;
            color:#666;
            text-decoration:none;
        }

        .forgot:hover{
            color:#4f46e5;
        }

        .erro{
            background:#fee2e2;
            color:#dc2626;
            padding:10px;
            border-radius:8px;
            margin-bottom:15px;
            text-align:center;
        }

        .sucesso{
            background:#dcfce7;
            color:#16a34a;
            padding:10px;
            border-radius:8px;
            margin-bottom:15px;
            text-align:center;
        }

    </style>

</head>
<body>

<div class="login-box">

    <h1>Login</h1>

    <?php if(session()->getFlashdata('error')): ?>

        <div class="erro">
            <?= session()->getFlashdata('error') ?>
        </div>

    <?php endif; ?>

    <?php if(session()->getFlashdata('success')): ?>

        <div class="sucesso">
            <?= session()->getFlashdata('success') ?>
        </div>

    <?php endif; ?>

    <form action="/autenticar" method="post">

        <input type="email" name="email" placeholder="Digite seu e-mail">

        <input type="password" name="senha" placeholder="Digite sua senha">

        <a class="forgot" href="#">
            Esqueci minha senha
        </a>

        <button type="submit">Entrar</button>

    </form>

    <a class="register" href="/register">
        Cadastrar usuário
    </a>

</div>

</body>
</html>