<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial, Helvetica, sans-serif;
        }

        body{
            background:linear-gradient(135deg, #4f46e5, #7c3aed);
            height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
        }

        .register-box{
            background:white;
            width:380px;
            padding:40px;
            border-radius:15px;
            box-shadow:0 10px 25px rgba(0,0,0,0.2);
        }

        h1{
            text-align:center;
            margin-bottom:30px;
            color:#333;
        }

        input{
            width:100%;
            padding:12px;
            margin-bottom:15px;
            border:1px solid #ccc;
            border-radius:8px;
            outline:none;
            transition:0.3s;
        }

        input:focus{
            border-color:#7c3aed;
        }

        button{
            width:100%;
            padding:12px;
            border:none;
            border-radius:8px;
            background:#4f46e5;
            color:white;
            font-size:16px;
            cursor:pointer;
            transition:0.3s;
        }

        button:hover{
            background:#4338ca;
        }

        .login-link{
            display:block;
            text-align:center;
            margin-top:20px;
            text-decoration:none;
            color:#4f46e5;
            font-weight:bold;
        }

        .erro{
            background:#fee2e2;
            color:#dc2626;
            padding:10px;
            border-radius:8px;
            margin-bottom:15px;
            text-align:center;
        }

        .info{
            text-align:center;
            color:#666;
            margin-bottom:20px;
            font-size:14px;
        }

    </style>

</head>
<body>

<div class="register-box">

    <h1>Criar Conta</h1>

    <p class="info">
        Preencha os dados para criar sua conta
    </p>

    <?php if(session()->getFlashdata('error')): ?>

        <div class="erro">
            <?= session()->getFlashdata('error') ?>
        </div>

    <?php endif; ?>

    <form action="/salvar" method="post">

        <input type="text" name="nome" placeholder="Digite seu nome">

        <input type="email" name="email" placeholder="Digite seu e-mail">

        <input type="password" name="senha" placeholder="Digite sua senha">

        <input type="password" name="confirmar_senha" placeholder="Confirme sua senha">

        <button type="submit">
            Cadastrar
        </button>

    </form>

    <a class="login-link" href="/login">
        Já possui conta? Fazer login
    </a>

</div>

</body>
</html>